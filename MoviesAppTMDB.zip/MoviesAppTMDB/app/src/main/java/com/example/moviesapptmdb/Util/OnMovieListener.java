package com.example.moviesapptmdb.Util;

import android.view.View;

public interface OnMovieListener {

    void onMovieClick(View v, int position);
}
