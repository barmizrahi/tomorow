package com.example.moviesapptmdb;

import retrofit2.Call;

public class HelperData {
    private Call<MovieList> callPopMovies;
    private Call<MovieList> callTopMovies;

    public HelperData(){}

    public HelperData(Call<MovieList> callPop,Call<MovieList> callTop){
        callPopMovies = callPop;
        callTopMovies = callTop;
    }

    public Call<MovieList> getCallPopMovies() {
        return callPopMovies;
    }

    public Call<MovieList> getCallTopMovies() {
        return callTopMovies;
    }
}
