package com.example.moviesapptmdb;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;


import com.example.moviesapptmdb.Util.Adaptery;
import com.example.moviesapptmdb.Util.OnMovieListener;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity implements OnMovieListener {

    private static String JSON_URL1 = "https://api.themoviedb.org/3/movie/popular?api_key=3930eda0423c873bc5ce559094909f9d";

    //json: https://run.mocky.io/v3/669bfc8d-6f62-4206-b7d1-ab3f5e6d4167
    //json popular movies: https://api.themoviedb.org/3/movie/popular?api_key=3930eda0423c873bc5ce559094909f9d
    List<MovieModelClass> popMovieList;
    public static Call<MovieList> callTopMovies;
    private RecyclerView recyclerView;
    private ImageView imageView;
    private TextView topMoviesText;
    private Button topMovies;

    static Adaptery adaptery;
    private String id,name;
    private String img;



    public List<MovieModelClass> getPopMovieList() {
        return popMovieList;
    }

    public void setPopMovieList(List<MovieModelClass> popMovieList) {
        this.popMovieList = popMovieList;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        popMovieList = new ArrayList<>();

        topMovies = findViewById(R.id.BTN_top_movies);
        topMoviesText= findViewById(R.id.TXT_top_movies);
        recyclerView = findViewById(R.id.recyclerView);



        //execute:
        //String path = "3/movie/popular";
        //Call<MovieList> callPopMovies = AppManager.jsonPopMovies.getPopularMovies(path);
        HelperData helperData = Activity_Splash.helperData;
        Call<MovieList> callPopMovies = null;
        if(helperData != null){
            callPopMovies = helperData.getCallPopMovies();
        }

        callPopMovies.enqueue(new Callback<MovieList>() {
            @Override
            public void onResponse(Call<MovieList> call, Response<MovieList> response) {
                //successful
                if(!response.isSuccessful()){ //200->300 good otherwise bad
                    //set text to response.code -> http code
                    Log.d("bar","" + response.code());
                    return;
                }
                List<MovieModelClass> popMovies = response.body().movies;
             //   for(MovieModelClass model: popMovies){
                for(int i=0;i<popMovies.size();i++){

                    MovieModelClass model = new MovieModelClass();
                    model.setId(popMovies.get(i).getId());
                    model.setName(popMovies.get(i).getName());
                    model.setImage(popMovies.get(i).getImage());

                    //no reason for this part either why cant
                    popMovieList.add(model);

                }
                PutDataIntoRecyclerView(popMovieList);

            }

            @Override
            public void onFailure(Call<MovieList> call, Throwable t) {
                //something bad happened t.getMessage() will indicate what
                Log.d("noa",t.getMessage());

            }
        });

        topMovies.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "3/movie/top_rated";
                 callTopMovies = AppManager.jsonPopMovies.getTopMovies(url);
                startActivity(new Intent(MainActivity.this, TopMoviesActivity.class));
            }
        });

    }

    private void PutDataIntoRecyclerView(List<MovieModelClass> movieList){
         adaptery = new Adaptery(this,this::onMovieClick,movieList);
        // recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setLayoutManager(new GridLayoutManager(this,2));

        recyclerView.setAdapter(adaptery);
    }

    @Override
    public void onMovieClick(View v, int position) {
        MSPV3.getMe().putString(getString(R.string.ID),popMovieList.get(position).getId());
        MSPV3.getMe().putString(getString(R.string.NAME),popMovieList.get(position).getName());
        MSPV3.getMe().putString(getString(R.string.IMG),popMovieList.get(position).getImage());
        startActivity(new Intent(MainActivity.this, PopUpActivity.class));
    }


}